from unittest import result
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from boto3.dynamodb.conditions import Key
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from jinja2 import Template
import boto3

dynamodb = boto3.resource("dynamodb" , region_name="eu-central-1")
tablename="cancer_research_data"
table= dynamodb.Table(tablename)
app = FastAPI()

templates = Jinja2Templates(directory="HTMLTemplate")
app.mount("/static", StaticFiles(directory="static"), name="static")
@app.get("/")
def index(request: Request):
    data=get_data()
    diseaseType = []
    primarySite = []
    caseId = []
    updatedDateTime = []

    for item in data:
       diseaseType.append( item["disease_type"])
       primarySite.append( item["primary_site"] )
       caseId.append( item["case_id"] )
       updatedDateTime.append( item["updated_datetime"] )

           
    return templates.TemplateResponse ("table.html",{"request": request,"primarySiteValues":primarySite,"diseaseTypeValues": diseaseType,"caseIdValues":caseId,"updateDateTimeValue":updatedDateTime})

def get_data():
    response = table.scan() 
    return response["Items"]

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")


